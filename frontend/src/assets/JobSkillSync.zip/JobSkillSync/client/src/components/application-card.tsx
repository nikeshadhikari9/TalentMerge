import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { User, Mail, Award } from "lucide-react";
import { Application, User as UserType } from "@shared/schema";

interface ApplicationCardProps {
  application: Application & {
    user?: UserType;
    job?: {
      title: string;
      requiredSkills: string[];
    };
  };
  onContact?: (userId: number) => void;
  onViewProfile?: (userId: number) => void;
  showJobInfo?: boolean;
}

export default function ApplicationCard({ 
  application, 
  onContact, 
  onViewProfile,
  showJobInfo = false 
}: ApplicationCardProps) {
  const formatDate = (date: Date) => {
    const now = new Date();
    const diffTime = Math.abs(now.getTime() - date.getTime());
    const diffHours = Math.ceil(diffTime / (1000 * 60 * 60));
    
    if (diffHours < 24) return `${diffHours} hours ago`;
    const diffDays = Math.ceil(diffHours / 24);
    if (diffDays === 1) return "1 day ago";
    if (diffDays < 7) return `${diffDays} days ago`;
    return `${Math.ceil(diffDays / 7)} weeks ago`;
  };

  const calculateMatchScore = () => {
    if (!application.user?.skills || !application.job?.requiredSkills) return 0;
    
    const userSkills = application.user.skills.map(s => s.toLowerCase());
    const jobSkills = application.job.requiredSkills.map(s => s.toLowerCase());
    
    const matchingSkills = userSkills.filter(skill => 
      jobSkills.some(jobSkill => jobSkill.includes(skill) || skill.includes(jobSkill))
    );
    
    return Math.round((matchingSkills.length / jobSkills.length) * 100);
  };

  const matchScore = calculateMatchScore();
  const getMatchColor = (score: number) => {
    if (score >= 80) return "text-success";
    if (score >= 60) return "text-warning";
    return "text-destructive";
  };

  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex justify-between items-start mb-4">
          <div className="flex items-center">
            <div className="w-12 h-12 bg-gray-200 rounded-full flex items-center justify-center mr-4">
              {application.user?.profilePicture ? (
                <img
                  src={application.user.profilePicture}
                  alt="Profile"
                  className="w-12 h-12 rounded-full object-cover"
                />
              ) : (
                <User className="text-gray-500 w-5 h-5" />
              )}
            </div>
            <div>
              <h3 className="text-lg font-semibold text-gray-900">
                {application.user?.fullName || "Unknown User"}
              </h3>
              {showJobInfo && application.job ? (
                <p className="text-gray-600">Applied for {application.job.title}</p>
              ) : (
                <p className="text-gray-600">@{application.user?.username}</p>
              )}
              <p className="text-sm text-gray-500">Applied {formatDate(application.appliedAt!)}</p>
            </div>
          </div>
          <div className="flex space-x-2">
            {onContact && (
              <Button
                onClick={() => onContact(application.userId)}
                className="bg-success hover:bg-green-700"
              >
                <Mail className="w-4 h-4 mr-2" />
                Contact
              </Button>
            )}
            {onViewProfile && (
              <Button
                variant="outline"
                onClick={() => onViewProfile(application.userId)}
              >
                View Profile
              </Button>
            )}
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-6 mb-4">
          <div>
            <h4 className="text-sm font-medium text-gray-700 mb-2">Skills</h4>
            <div className="flex flex-wrap gap-1">
              {application.user?.skills?.slice(0, 4).map((skill, index) => (
                <Badge key={index} variant="secondary" className="text-xs">
                  {skill}
                </Badge>
              ))}
              {(application.user?.skills?.length || 0) > 4 && (
                <Badge variant="secondary" className="text-xs">
                  +{(application.user?.skills?.length || 0) - 4} more
                </Badge>
              )}
            </div>
          </div>
          
          <div>
            <h4 className="text-sm font-medium text-gray-700 mb-2">Certificates</h4>
            <div className="space-y-1">
              {application.user?.certificates?.slice(0, 2).map((cert, index) => (
                <div key={index} className="flex items-center text-xs text-success">
                  <Award className="w-3 h-3 mr-1" />
                  <span>{cert}</span>
                </div>
              ))}
              {(application.user?.certificates?.length || 0) === 0 && (
                <span className="text-xs text-gray-500">No certificates yet</span>
              )}
            </div>
          </div>
          
          <div>
            <h4 className="text-sm font-medium text-gray-700 mb-2">Match Score</h4>
            <div className="flex items-center">
              <div className="w-full bg-gray-200 rounded-full h-2 mr-2">
                <div
                  className={`h-2 rounded-full ${
                    matchScore >= 80 ? "bg-success" : 
                    matchScore >= 60 ? "bg-warning" : 
                    "bg-destructive"
                  }`}
                  style={{ width: `${matchScore}%` }}
                ></div>
              </div>
              <span className={`text-sm font-medium ${getMatchColor(matchScore)}`}>
                {matchScore}%
              </span>
            </div>
          </div>
        </div>

        {application.user?.bio && (
          <div className="border-t border-gray-200 pt-4">
            <h4 className="text-sm font-medium text-gray-700 mb-2">Bio</h4>
            <p className="text-sm text-gray-600">{application.user.bio}</p>
          </div>
        )}

        <div className="mt-4 flex justify-between items-center">
          <Badge
            variant={
              application.status === "accepted" ? "default" :
              application.status === "rejected" ? "destructive" :
              "secondary"
            }
          >
            {application.status.charAt(0).toUpperCase() + application.status.slice(1)}
          </Badge>
        </div>
      </CardContent>
    </Card>
  );
}
