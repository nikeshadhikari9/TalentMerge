import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Building, MapPin, Clock, DollarSign } from "lucide-react";
import { Job } from "@shared/schema";

interface JobCardProps {
  job: Job & { organization?: { name: string; username: string } };
  onApply?: (jobId: number) => void;
  onEdit?: (job: Job) => void;
  onDelete?: (jobId: number) => void;
  showActions?: "apply" | "manage" | "none";
  applicationCount?: number;
}

export default function JobCard({ 
  job, 
  onApply, 
  onEdit, 
  onDelete, 
  showActions = "none",
  applicationCount 
}: JobCardProps) {
  const formatSalary = (salary: string) => {
    return salary.includes('$') ? salary : `$${salary}`;
  };

  const formatDate = (date: Date) => {
    const now = new Date();
    const diffTime = Math.abs(now.getTime() - date.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 1) return "1 day ago";
    if (diffDays < 7) return `${diffDays} days ago`;
    if (diffDays < 30) return `${Math.ceil(diffDays / 7)} weeks ago`;
    return `${Math.ceil(diffDays / 30)} months ago`;
  };

  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardContent className="p-6">
        <div className="flex justify-between items-start mb-4">
          <div className="flex items-center">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mr-4">
              <Building className="text-primary w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-gray-900">{job.title}</h3>
              <p className="text-gray-600">
                {job.organization?.name || `Organization #${job.organizationId}`}
              </p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-lg font-semibold text-gray-900">{formatSalary(job.salary)}</p>
            <p className="text-sm text-gray-500">per year</p>
          </div>
        </div>

        <p className="text-gray-600 mb-4 line-clamp-3">{job.description}</p>

        <div className="flex flex-wrap gap-2 mb-4">
          {job.requiredSkills.map((skill, index) => (
            <Badge key={index} variant="secondary">
              {skill}
            </Badge>
          ))}
        </div>

        <div className="flex justify-between items-center">
          <div className="flex items-center text-sm text-gray-500 space-x-4">
            <div className="flex items-center">
              <MapPin className="w-4 h-4 mr-1" />
              <span>{job.location}</span>
            </div>
            <div className="flex items-center">
              <Clock className="w-4 h-4 mr-1" />
              <span>Posted {formatDate(job.createdAt!)}</span>
            </div>
            {applicationCount !== undefined && (
              <div className="flex items-center">
                <span>{applicationCount} applications</span>
              </div>
            )}
          </div>

          <div className="flex space-x-2">
            {showActions === "apply" && onApply && (
              <Button onClick={() => onApply(job.id)}>
                Apply Now
              </Button>
            )}
            {showActions === "manage" && (
              <>
                {onEdit && (
                  <Button variant="outline" onClick={() => onEdit(job)}>
                    Edit
                  </Button>
                )}
                {onDelete && (
                  <Button variant="destructive" onClick={() => onDelete(job.id)}>
                    Delete
                  </Button>
                )}
              </>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
