import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Camera } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface ProfileUploadProps {
  currentImage?: string;
  onImageUpdate: (imageUrl: string) => void;
  isOrganization?: boolean;
}

export default function ProfileUpload({ currentImage, onImageUpdate, isOrganization = false }: ProfileUploadProps) {
  const { toast } = useToast();
  const [isUploading, setIsUploading] = useState(false);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) { // 5MB limit
      toast({
        title: "File too large",
        description: "Please select an image smaller than 5MB.",
        variant: "destructive",
      });
      return;
    }

    setIsUploading(true);
    
    try {
      // In a real app, this would upload to a file storage service
      // For now, we'll create a data URL
      const reader = new FileReader();
      reader.onload = (event) => {
        const imageUrl = event.target?.result as string;
        onImageUpdate(imageUrl);
        toast({
          title: "Image uploaded successfully",
          description: isOrganization ? "Organization logo updated." : "Profile picture updated.",
        });
      };
      reader.readAsDataURL(file);
    } catch (error) {
      toast({
        title: "Upload failed",
        description: "Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div className="relative">
      <input
        type="file"
        accept="image/*"
        onChange={handleFileChange}
        className="hidden"
        id="image-upload"
        disabled={isUploading}
      />
      <label htmlFor="image-upload" className="cursor-pointer">
        <div className={`w-20 h-20 ${isOrganization ? 'rounded-lg' : 'rounded-full'} mx-auto mb-3 flex items-center justify-center transition-colors ${
          currentImage 
            ? 'bg-cover bg-center' 
            : 'bg-gray-200 hover:bg-gray-300'
        }`}
        style={currentImage ? { backgroundImage: `url(${currentImage})` } : {}}
        >
          {!currentImage && (
            <Camera className="text-gray-500 w-5 h-5" />
          )}
        </div>
      </label>
      {isUploading && (
        <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-50 rounded-full">
          <div className="w-6 h-6 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
        </div>
      )}
    </div>
  );
}
