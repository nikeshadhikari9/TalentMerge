import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Check, Circle } from "lucide-react";
import { Roadmap, UserProgress } from "@shared/schema";

interface RoadmapCardProps {
  roadmap: Roadmap;
  progress?: UserProgress;
  onStart?: (roadmapId: number) => void;
  onContinue?: (progressId: number) => void;
}

export default function RoadmapCard({ roadmap, progress, onStart, onContinue }: RoadmapCardProps) {
  const getColorClasses = (color: string) => {
    switch (color) {
      case "blue":
        return {
          bg: "bg-blue-100",
          text: "text-blue-600",
          button: "bg-blue-600 hover:bg-blue-700"
        };
      case "green":
        return {
          bg: "bg-green-100",
          text: "text-green-600",
          button: "bg-green-600 hover:bg-green-700"
        };
      case "purple":
        return {
          bg: "bg-purple-100",
          text: "text-purple-600",
          button: "bg-purple-600 hover:bg-purple-700"
        };
      case "indigo":
        return {
          bg: "bg-indigo-100",
          text: "text-indigo-600",
          button: "bg-indigo-600 hover:bg-indigo-700"
        };
      default:
        return {
          bg: "bg-gray-100",
          text: "text-gray-600",
          button: "bg-gray-600 hover:bg-gray-700"
        };
    }
  };

  const colors = getColorClasses(roadmap.color);
  const progressPercentage = progress?.progress || 0;

  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardContent className="p-6">
        <div className="flex items-center mb-4">
          <div className={`w-12 h-12 ${colors.bg} rounded-lg flex items-center justify-center mr-4`}>
            <i className={`${roadmap.icon} ${colors.text} text-xl`}></i>
          </div>
          <div>
            <h3 className="font-semibold text-gray-900">{roadmap.name}</h3>
            <p className="text-sm text-gray-500">{roadmap.skill}</p>
          </div>
        </div>

        <p className="text-gray-600 text-sm mb-4">{roadmap.description}</p>

        {progress && (
          <div className="mb-4">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm font-medium text-gray-700">Progress</span>
              <span className="text-sm text-gray-500">{progressPercentage}%</span>
            </div>
            <Progress value={progressPercentage} className="h-2" />
          </div>
        )}

        <div className="space-y-2 mb-4">
          {roadmap.modules.slice(0, 3).map((module, index) => {
            const isCompleted = progress?.completedModules.includes(module.id) || false;
            return (
              <div key={module.id} className="flex items-center text-sm">
                {isCompleted ? (
                  <Check className="text-success w-4 h-4 mr-2" />
                ) : (
                  <Circle className="text-gray-400 w-4 h-4 mr-2" />
                )}
                <span className="text-gray-600">{module.name}</span>
              </div>
            );
          })}
          {roadmap.modules.length > 3 && (
            <div className="text-sm text-gray-500 ml-6">
              +{roadmap.modules.length - 3} more modules
            </div>
          )}
        </div>

        <Button
          className={`w-full text-white ${colors.button}`}
          onClick={() => {
            if (progress) {
              onContinue?.(progress.id);
            } else {
              onStart?.(roadmap.id);
            }
          }}
        >
          {progress ? 
            (progress.isCompleted ? "Completed" : "Continue Learning") : 
            "Start Learning"
          }
        </Button>

        {progress?.isCompleted && (
          <div className="mt-2 text-center">
            <span className="text-sm text-success font-medium">
              🎉 Certificate Earned!
            </span>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
