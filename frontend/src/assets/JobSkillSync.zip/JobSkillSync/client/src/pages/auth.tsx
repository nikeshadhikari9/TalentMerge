import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Briefcase, ArrowLeft } from "lucide-react";

export default function AuthPage() {
  const navigate = useNavigate();
  const { register } = useAuth();
  const { toast } = useToast();
  const [userRole, setUserRole] = useState<"jobseeker" | "organization">("jobseeker");
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const formData = new FormData(e.currentTarget);
      const userData: any = {
        role: userRole,
      };

      if (userRole === "jobseeker") {
        userData.fullName = formData.get("fullName");
        userData.username = formData.get("username");
        userData.email = formData.get("email");
        userData.password = formData.get("password");
        userData.skills = [];
        userData.certificates = [];
      } else {
        userData.fullName = formData.get("organizationName");
        userData.organizationName = formData.get("organizationName");
        userData.username = formData.get("orgUsername");
        userData.email = formData.get("orgEmail");
        userData.password = formData.get("orgPassword");
        userData.location = formData.get("location");
        userData.organizationType = formData.get("organizationType");
      }

      await register(userData);
      
      toast({
        title: "Account created successfully!",
        description: "Welcome to JobLearn platform.",
      });

      // Redirect based on role
      if (userRole === "jobseeker") {
        navigate("/dashboard/user");
      } else {
        navigate("/dashboard/organization");
      }
    } catch (error) {
      toast({
        title: "Registration failed",
        description: error instanceof Error ? error.message : "Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-md mx-auto">
        <Card>
          <CardHeader>
            <div className="text-center">
              <div className="flex items-center justify-center space-x-2 mb-4">
                <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                  <Briefcase className="text-white w-4 h-4" />
                </div>
                <span className="text-xl font-bold text-gray-900">JobLearn</span>
              </div>
              <CardTitle className="text-2xl font-bold text-gray-900">Create Your Account</CardTitle>
              <p className="text-gray-600 mt-2">Join our community and start your journey</p>
            </div>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Role Selection */}
              <div>
                <Label htmlFor="role">I am a</Label>
                <Select value={userRole} onValueChange={(value: "jobseeker" | "organization") => setUserRole(value)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="jobseeker">Job Seeker</SelectItem>
                    <SelectItem value="organization">Organization</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Dynamic Form Fields */}
              {userRole === "jobseeker" ? (
                <>
                  <div>
                    <Label htmlFor="fullName">Full Name</Label>
                    <Input name="fullName" type="text" required />
                  </div>
                  <div>
                    <Label htmlFor="username">Username</Label>
                    <Input name="username" type="text" required />
                  </div>
                  <div>
                    <Label htmlFor="email">Email</Label>
                    <Input name="email" type="email" required />
                  </div>
                  <div>
                    <Label htmlFor="password">Password</Label>
                    <Input name="password" type="password" required />
                  </div>
                </>
              ) : (
                <>
                  <div>
                    <Label htmlFor="organizationName">Organization Name</Label>
                    <Input name="organizationName" type="text" required />
                  </div>
                  <div>
                    <Label htmlFor="orgUsername">Organization Username</Label>
                    <Input name="orgUsername" type="text" required />
                  </div>
                  <div>
                    <Label htmlFor="location">Location</Label>
                    <Input name="location" type="text" required />
                  </div>
                  <div>
                    <Label htmlFor="organizationType">Organization Type</Label>
                    <Select name="organizationType" required>
                      <SelectTrigger>
                        <SelectValue placeholder="Select type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="startup">Startup</SelectItem>
                        <SelectItem value="corporation">Corporation</SelectItem>
                        <SelectItem value="nonprofit">Non-Profit</SelectItem>
                        <SelectItem value="government">Government</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="orgEmail">Email</Label>
                    <Input name="orgEmail" type="email" required />
                  </div>
                  <div>
                    <Label htmlFor="orgPassword">Password</Label>
                    <Input name="orgPassword" type="password" required />
                  </div>
                </>
              )}

              <Button type="submit" className="w-full" disabled={isLoading}>
                {isLoading ? "Creating Account..." : "Create Account"}
              </Button>
            </form>

            <div className="mt-6 text-center">
              <Button
                variant="ghost"
                onClick={() => navigate("/")}
                className="text-primary hover:text-blue-700"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Home
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
