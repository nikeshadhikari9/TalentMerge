import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Briefcase, GraduationCap, Building, Check } from "lucide-react";

export default function LandingPage() {
  const navigate = useNavigate();
  const { isAuthenticated, user } = useAuth();

  useEffect(() => {
    if (isAuthenticated && user) {
      if (user.role === "jobseeker") {
        navigate("/dashboard/user");
      } else {
        navigate("/dashboard/organization");
      }
    }
  }, [isAuthenticated, user, navigate]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Navigation */}
      <nav className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <Briefcase className="text-white w-4 h-4" />
              </div>
              <span className="text-xl font-bold text-gray-900">JobLearn</span>
            </div>
            <Button onClick={() => navigate("/auth")}>
              Create Account
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center">
          <h1 className="text-5xl font-bold text-gray-900 mb-6">
            Your Career Journey Starts Here
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            Connect with opportunities, learn new skills, and advance your career with our comprehensive job and learning platform.
          </p>
          
          <div className="grid md:grid-cols-2 gap-8 mt-16">
            <Card className="p-8 hover:shadow-lg transition-shadow">
              <CardContent className="pt-0">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                  <GraduationCap className="text-primary w-6 h-6" />
                </div>
                <h3 className="text-xl font-semibold mb-3">For Job Seekers</h3>
                <p className="text-gray-600 mb-4">Learn new skills, track your progress, and find your dream job</p>
                <ul className="text-sm text-gray-500 space-y-2">
                  <li className="flex items-center">
                    <Check className="text-success w-4 h-4 mr-2" />
                    Skill-based learning roadmaps
                  </li>
                  <li className="flex items-center">
                    <Check className="text-success w-4 h-4 mr-2" />
                    Personalized job matching
                  </li>
                  <li className="flex items-center">
                    <Check className="text-success w-4 h-4 mr-2" />
                    Professional certifications
                  </li>
                </ul>
              </CardContent>
            </Card>
            
            <Card className="p-8 hover:shadow-lg transition-shadow">
              <CardContent className="pt-0">
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
                  <Building className="text-success w-6 h-6" />
                </div>
                <h3 className="text-xl font-semibold mb-3">For Organizations</h3>
                <p className="text-gray-600 mb-4">Find qualified candidates and build your team</p>
                <ul className="text-sm text-gray-500 space-y-2">
                  <li className="flex items-center">
                    <Check className="text-success w-4 h-4 mr-2" />
                    Smart candidate matching
                  </li>
                  <li className="flex items-center">
                    <Check className="text-success w-4 h-4 mr-2" />
                    Application management
                  </li>
                  <li className="flex items-center">
                    <Check className="text-success w-4 h-4 mr-2" />
                    Direct candidate communication
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
