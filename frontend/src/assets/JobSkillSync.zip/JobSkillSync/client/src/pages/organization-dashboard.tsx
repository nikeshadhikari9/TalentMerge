import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import ProfileUpload from "@/components/profile-upload";
import JobCard from "@/components/job-card";
import ApplicationCard from "@/components/application-card";
import { insertJobSchema } from "@shared/schema";
import { 
  Briefcase, Plus, Users, Building, Calendar,
  MapPin, DollarSign, FileText 
} from "lucide-react";
import { Job, Application, User } from "@shared/schema";
import { z } from "zod";

const jobFormSchema = insertJobSchema.extend({
  deadline: z.string().min(1, "Deadline is required"),
  requiredSkills: z.string().min(1, "Required skills are needed"),
});

type JobFormData = z.infer<typeof jobFormSchema>;

export default function OrganizationDashboard() {
  const [, setLocation] = useLocation();
  const { user, logout } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState<"jobs" | "applications">("jobs");
  const [bio, setBio] = useState(user?.bio || "");

  useEffect(() => {
    if (!user || user.role !== "organization") {
      setLocation("/auth");
    }
  }, [user, setLocation]);

  // Form for job posting
  const form = useForm<JobFormData>({
    resolver: zodResolver(jobFormSchema),
    defaultValues: {
      organizationId: user?.id || 0,
      title: "",
      description: "",
      requiredSkills: "",
      salary: "",
      location: "",
      deadline: "",
    },
  });

  // Queries
  const { data: organizationJobs = [] } = useQuery<Job[]>({
    queryKey: ["/api/jobs/organization", user?.id],
    enabled: !!user,
  });

  const { data: applications = [] } = useQuery<(Application & { user?: User; job?: Job })[]>({
    queryKey: ["/api/applications/organization", user?.id],
    enabled: !!user && organizationJobs.length > 0,
    queryFn: async () => {
      const allApps = await Promise.all(
        organizationJobs.map(async (job) => {
          const response = await fetch(`/api/applications/job/${job.id}`);
          if (!response.ok) throw new Error("Failed to fetch applications");
          const jobApps = await response.json();
          return jobApps.map((app: any) => ({ ...app, job }));
        })
      );
      return allApps.flat();
    },
  });

  // Mutations
  const updateUserMutation = useMutation({
    mutationFn: (updates: any) => apiRequest("PUT", `/api/users/${user?.id}`, updates),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      toast({
        title: "Profile updated",
        description: "Your organization profile has been updated successfully.",
      });
    },
  });

  const createJobMutation = useMutation({
    mutationFn: (jobData: JobFormData) => {
      const data = {
        ...jobData,
        requiredSkills: jobData.requiredSkills.split(",").map(s => s.trim()),
        deadline: new Date(jobData.deadline),
      };
      return apiRequest("POST", "/api/jobs", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/jobs"] });
      form.reset();
      toast({
        title: "Job posted successfully!",
        description: "Your job posting is now live and candidates will be notified.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to post job",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const deleteJobMutation = useMutation({
    mutationFn: (jobId: number) => apiRequest("DELETE", `/api/jobs/${jobId}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/jobs"] });
      toast({
        title: "Job deleted",
        description: "The job posting has been removed.",
      });
    },
  });

  const handleBioUpdate = () => {
    updateUserMutation.mutate({ bio });
  };

  const handleProfilePictureUpdate = (imageUrl: string) => {
    updateUserMutation.mutate({ profilePicture: imageUrl });
  };

  const handleJobSubmit = (data: JobFormData) => {
    createJobMutation.mutate(data);
  };

  const handleDeleteJob = (jobId: number) => {
    if (confirm("Are you sure you want to delete this job posting?")) {
      deleteJobMutation.mutate(jobId);
    }
  };

  const handleContactApplicant = (userId: number) => {
    toast({
      title: "Contact feature",
      description: "Email integration would be implemented here to contact the applicant.",
    });
  };

  const handleViewProfile = (userId: number) => {
    toast({
      title: "Profile viewer",
      description: "Detailed profile view would be implemented here.",
    });
  };

  // Get application count for each job
  const getApplicationCount = (jobId: number) => {
    return applications.filter(app => app.jobId === jobId).length;
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="flex">
        {/* Left Sidebar */}
        <div className="w-64 bg-white shadow-sm border-r border-gray-200 min-h-screen">
          <div className="p-6">
            <div className="flex items-center space-x-2 mb-8">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <Briefcase className="text-white w-4 h-4" />
              </div>
              <span className="text-xl font-bold text-gray-900">JobLearn</span>
            </div>

            {/* Organization Profile Section */}
            <div className="border-b border-gray-200 pb-6 mb-6">
              <div className="text-center">
                <ProfileUpload
                  currentImage={user.profilePicture || undefined}
                  onImageUpdate={handleProfilePictureUpdate}
                  isOrganization={true}
                />
                <h3 className="font-semibold text-gray-900">
                  {user.organizationName || user.fullName}
                </h3>
                <p className="text-sm text-gray-500">@{user.username}</p>
                <p className="text-sm text-gray-500">{user.email}</p>
                {user.location && (
                  <p className="text-sm text-gray-500 flex items-center justify-center mt-1">
                    <MapPin className="w-3 h-3 mr-1" />
                    {user.location}
                  </p>
                )}
              </div>
              
              <div className="mt-4">
                <h4 className="text-sm font-medium text-gray-900 mb-2">About</h4>
                <Textarea
                  value={bio}
                  onChange={(e) => setBio(e.target.value)}
                  onBlur={handleBioUpdate}
                  rows={3}
                  placeholder="Tell candidates about your organization..."
                />
              </div>
            </div>

            {/* Navigation */}
            <nav className="space-y-2">
              <Button
                variant={activeTab === "jobs" ? "default" : "ghost"}
                className="w-full justify-start"
                onClick={() => setActiveTab("jobs")}
              >
                <Plus className="w-4 h-4 mr-2" />
                Post Jobs
              </Button>
              <Button
                variant={activeTab === "applications" ? "default" : "ghost"}
                className="w-full justify-start"
                onClick={() => setActiveTab("applications")}
              >
                <Users className="w-4 h-4 mr-2" />
                Applications
              </Button>
            </nav>

            <div className="mt-8">
              <Button variant="outline" onClick={logout} className="w-full">
                Logout
              </Button>
            </div>
          </div>
        </div>

        {/* Main Content Area */}
        <div className="flex-1 p-8">
          {activeTab === "jobs" && (
            <div>
              <div className="mb-8">
                <h1 className="text-3xl font-bold text-gray-900 mb-2">Post New Job</h1>
                <p className="text-gray-600">Create a job posting to find the best candidates</p>
              </div>

              <Card className="p-8 mb-12">
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(handleJobSubmit)} className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-6">
                      <FormField
                        control={form.control}
                        name="title"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Job Title</FormLabel>
                            <FormControl>
                              <Input {...field} placeholder="e.g. Frontend React Developer" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="salary"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Salary</FormLabel>
                            <FormControl>
                              <Input {...field} placeholder="e.g. $80,000 - $100,000" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <FormField
                      control={form.control}
                      name="description"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Job Description</FormLabel>
                          <FormControl>
                            <Textarea
                              {...field}
                              rows={5}
                              placeholder="Describe the role, responsibilities, and what you're looking for..."
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <div className="grid md:grid-cols-3 gap-6">
                      <FormField
                        control={form.control}
                        name="requiredSkills"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Required Skills</FormLabel>
                            <FormControl>
                              <Input {...field} placeholder="React, Node.js, JavaScript" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="location"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Location</FormLabel>
                            <FormControl>
                              <Input {...field} placeholder="Remote, New York, etc." />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="deadline"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Application Deadline</FormLabel>
                            <FormControl>
                              <Input {...field} type="date" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <Button 
                      type="submit" 
                      disabled={createJobMutation.isPending}
                      className="px-8"
                    >
                      {createJobMutation.isPending ? "Posting..." : "Post Job"}
                    </Button>
                  </form>
                </Form>
              </Card>

              {/* Posted Jobs */}
              <div>
                <h2 className="text-2xl font-bold text-gray-900 mb-6">Your Posted Jobs</h2>
                <div className="space-y-4">
                  {organizationJobs.length > 0 ? (
                    organizationJobs.map((job) => (
                      <JobCard
                        key={job.id}
                        job={job}
                        showActions="manage"
                        applicationCount={getApplicationCount(job.id)}
                        onEdit={(job) => {
                          toast({
                            title: "Edit job",
                            description: "Job editing would be implemented here.",
                          });
                        }}
                        onDelete={handleDeleteJob}
                      />
                    ))
                  ) : (
                    <Card className="p-8 text-center">
                      <p className="text-gray-600">No jobs posted yet. Create your first job posting above.</p>
                    </Card>
                  )}
                </div>
              </div>
            </div>
          )}

          {activeTab === "applications" && (
            <div>
              <div className="mb-8">
                <h1 className="text-3xl font-bold text-gray-900 mb-2">Job Applications</h1>
                <p className="text-gray-600">Review and manage candidate applications</p>
              </div>

              <div className="space-y-6">
                {applications.length > 0 ? (
                  applications.map((application) => (
                    <ApplicationCard
                      key={application.id}
                      application={application}
                      showJobInfo={true}
                      onContact={handleContactApplicant}
                      onViewProfile={handleViewProfile}
                    />
                  ))
                ) : (
                  <Card className="p-8 text-center">
                    <FileText className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-600 mb-2">No applications received yet.</p>
                    <p className="text-gray-500 text-sm">
                      Applications will appear here once candidates start applying to your job postings.
                    </p>
                  </Card>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
