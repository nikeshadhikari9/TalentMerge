import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import ProfileUpload from "@/components/profile-upload";
import JobCard from "@/components/job-card";
import RoadmapCard from "@/components/roadmap-card";
import { 
  Briefcase, GraduationCap, Search, Bell, Award, 
  MapPin, DollarSign, Filter 
} from "lucide-react";
import { Job, Roadmap, UserProgress, Notification } from "@shared/schema";

export default function UserDashboard() {
  const [, setLocation] = useLocation();
  const { user, logout } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState<"learn" | "jobs">("learn");
  const [bio, setBio] = useState(user?.bio || "");
  const [jobFilters, setJobFilters] = useState({
    skills: "",
    location: "",
    salary: ""
  });

  useEffect(() => {
    if (!user || user.role !== "jobseeker") {
      setLocation("/auth");
    }
  }, [user, setLocation]);

  // Queries
  const { data: roadmaps = [] } = useQuery<Roadmap[]>({
    queryKey: ["/api/roadmaps"],
  });

  const { data: userProgress = [] } = useQuery<(UserProgress & { roadmap?: Roadmap })[]>({
    queryKey: ["/api/progress/user", user?.id],
    enabled: !!user,
  });

  const { data: jobs = [] } = useQuery<Job[]>({
    queryKey: ["/api/jobs"],
  });

  const { data: notifications = [] } = useQuery<Notification[]>({
    queryKey: ["/api/notifications", user?.id],
    enabled: !!user,
  });

  // Mutations
  const updateUserMutation = useMutation({
    mutationFn: (updates: any) => apiRequest("PUT", `/api/users/${user?.id}`, updates),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      toast({
        title: "Profile updated",
        description: "Your profile has been updated successfully.",
      });
    },
  });

  const startRoadmapMutation = useMutation({
    mutationFn: (roadmapId: number) => 
      apiRequest("POST", "/api/progress", { userId: user?.id, roadmapId }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/progress"] });
      toast({
        title: "Roadmap started!",
        description: "You've started a new learning journey.",
      });
    },
  });

  const applyToJobMutation = useMutation({
    mutationFn: (jobId: number) => 
      apiRequest("POST", "/api/applications", { userId: user?.id, jobId }),
    onSuccess: () => {
      toast({
        title: "Application submitted!",
        description: "Your job application has been submitted successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Application failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleBioUpdate = () => {
    updateUserMutation.mutate({ bio });
  };

  const handleProfilePictureUpdate = (imageUrl: string) => {
    updateUserMutation.mutate({ profilePicture: imageUrl });
  };

  const handleStartRoadmap = (roadmapId: number) => {
    startRoadmapMutation.mutate(roadmapId);
  };

  const handleApplyToJob = (jobId: number) => {
    applyToJobMutation.mutate(jobId);
  };

  // Filter jobs based on filters
  const filteredJobs = jobs.filter(job => {
    if (jobFilters.skills && !job.requiredSkills.some(skill => 
      skill.toLowerCase().includes(jobFilters.skills.toLowerCase())
    )) {
      return false;
    }
    if (jobFilters.location && !job.location.toLowerCase().includes(jobFilters.location.toLowerCase())) {
      return false;
    }
    return true;
  });

  // Get progress for roadmaps
  const getRoadmapProgress = (roadmapId: number) => {
    return userProgress.find(p => p.roadmapId === roadmapId);
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="flex">
        {/* Left Sidebar */}
        <div className="w-64 bg-white shadow-sm border-r border-gray-200 min-h-screen">
          <div className="p-6">
            <div className="flex items-center space-x-2 mb-8">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <Briefcase className="text-white w-4 h-4" />
              </div>
              <span className="text-xl font-bold text-gray-900">JobLearn</span>
            </div>

            {/* Profile Section */}
            <div className="border-b border-gray-200 pb-6 mb-6">
              <div className="text-center">
                <ProfileUpload
                  currentImage={user.profilePicture || undefined}
                  onImageUpdate={handleProfilePictureUpdate}
                />
                <h3 className="font-semibold text-gray-900">{user.fullName}</h3>
                <p className="text-sm text-gray-500">@{user.username}</p>
                <p className="text-sm text-gray-500">{user.email}</p>
              </div>
              
              <div className="mt-4">
                <h4 className="text-sm font-medium text-gray-900 mb-2">Bio</h4>
                <Textarea
                  value={bio}
                  onChange={(e) => setBio(e.target.value)}
                  onBlur={handleBioUpdate}
                  rows={3}
                  placeholder="Tell us about yourself..."
                />
              </div>
              
              <div className="mt-4">
                <h4 className="text-sm font-medium text-gray-900 mb-2">Skills</h4>
                <div className="flex flex-wrap gap-1">
                  {user.skills?.length ? (
                    user.skills.map((skill, index) => (
                      <Badge key={index} variant="secondary" className="text-xs">
                        {skill}
                      </Badge>
                    ))
                  ) : (
                    <span className="text-sm text-gray-500">Complete roadmaps to earn skills</span>
                  )}
                </div>
              </div>
              
              <div className="mt-4">
                <h4 className="text-sm font-medium text-gray-900 mb-2">Certificates</h4>
                <div className="space-y-1">
                  {user.certificates?.length ? (
                    user.certificates.map((cert, index) => (
                      <div key={index} className="flex items-center text-sm text-success">
                        <Award className="w-3 h-3 mr-2" />
                        <span>{cert}</span>
                      </div>
                    ))
                  ) : (
                    <span className="text-sm text-gray-500">No certificates yet</span>
                  )}
                </div>
              </div>
            </div>

            {/* Navigation */}
            <nav className="space-y-2">
              <Button
                variant={activeTab === "learn" ? "default" : "ghost"}
                className="w-full justify-start"
                onClick={() => setActiveTab("learn")}
              >
                <GraduationCap className="w-4 h-4 mr-2" />
                Learn
              </Button>
              <Button
                variant={activeTab === "jobs" ? "default" : "ghost"}
                className="w-full justify-start"
                onClick={() => setActiveTab("jobs")}
              >
                <Search className="w-4 h-4 mr-2" />
                Search for Jobs
              </Button>
            </nav>

            {/* Notifications */}
            {notifications.length > 0 && (
              <div className="mt-6">
                <h4 className="text-sm font-medium text-gray-900 mb-2 flex items-center">
                  <Bell className="w-4 h-4 mr-2" />
                  Recent Notifications
                </h4>
                <div className="space-y-2">
                  {notifications.slice(0, 3).map((notif) => (
                    <div key={notif.id} className="text-xs p-2 bg-blue-50 rounded">
                      <p className="font-medium">{notif.title}</p>
                      <p className="text-gray-600">{notif.message}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="mt-8">
              <Button variant="outline" onClick={logout} className="w-full">
                Logout
              </Button>
            </div>
          </div>
        </div>

        {/* Main Content Area */}
        <div className="flex-1 p-8">
          {activeTab === "learn" && (
            <div>
              <div className="mb-8">
                <h1 className="text-3xl font-bold text-gray-900 mb-2">Learning Roadmaps</h1>
                <p className="text-gray-600">Choose a skill path and track your progress</p>
              </div>

              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {roadmaps.map((roadmap) => (
                  <RoadmapCard
                    key={roadmap.id}
                    roadmap={roadmap}
                    progress={getRoadmapProgress(roadmap.id)}
                    onStart={handleStartRoadmap}
                    onContinue={(progressId) => {
                      toast({
                        title: "Continue learning",
                        description: "Learning progress tracking would be implemented here.",
                      });
                    }}
                  />
                ))}
              </div>
            </div>
          )}

          {activeTab === "jobs" && (
            <div>
              <div className="mb-8">
                <h1 className="text-3xl font-bold text-gray-900 mb-2">Job Opportunities</h1>
                <p className="text-gray-600">Find jobs that match your skills</p>
              </div>

              {/* Job Filters */}
              <Card className="p-6 mb-6">
                <div className="grid md:grid-cols-4 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Skills</label>
                    <Select value={jobFilters.skills} onValueChange={(value) => setJobFilters(prev => ({ ...prev, skills: value }))}>
                      <SelectTrigger>
                        <SelectValue placeholder="All Skills" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="">All Skills</SelectItem>
                        <SelectItem value="React">React</SelectItem>
                        <SelectItem value="Node.js">Node.js</SelectItem>
                        <SelectItem value="JavaScript">JavaScript</SelectItem>
                        <SelectItem value="Python">Python</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Location</label>
                    <Select value={jobFilters.location} onValueChange={(value) => setJobFilters(prev => ({ ...prev, location: value }))}>
                      <SelectTrigger>
                        <SelectValue placeholder="All Locations" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="">All Locations</SelectItem>
                        <SelectItem value="Remote">Remote</SelectItem>
                        <SelectItem value="New York">New York</SelectItem>
                        <SelectItem value="San Francisco">San Francisco</SelectItem>
                        <SelectItem value="Seattle">Seattle</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Salary Range</label>
                    <Select value={jobFilters.salary} onValueChange={(value) => setJobFilters(prev => ({ ...prev, salary: value }))}>
                      <SelectTrigger>
                        <SelectValue placeholder="Any Salary" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="">Any Salary</SelectItem>
                        <SelectItem value="50k-70k">$50k - $70k</SelectItem>
                        <SelectItem value="70k-100k">$70k - $100k</SelectItem>
                        <SelectItem value="100k+">$100k+</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex items-end">
                    <Button className="w-full">
                      <Filter className="w-4 h-4 mr-2" />
                      Filter Jobs
                    </Button>
                  </div>
                </div>
              </Card>

              {/* Job Listings */}
              <div className="space-y-6">
                {filteredJobs.length > 0 ? (
                  filteredJobs.map((job) => (
                    <JobCard
                      key={job.id}
                      job={job}
                      showActions="apply"
                      onApply={handleApplyToJob}
                    />
                  ))
                ) : (
                  <Card className="p-8 text-center">
                    <p className="text-gray-600">No jobs found matching your criteria.</p>
                  </Card>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
