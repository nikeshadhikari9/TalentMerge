import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export interface CourseModule {
  id: string;
  title: string;
  description: string;
  content: string;
  duration: number; // in minutes
  type: 'video' | 'text' | 'quiz' | 'hands-on';
  isPremium: boolean;
  order: number;
}

export interface GeneratedCourse {
  title: string;
  description: string;
  skill: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  modules: CourseModule[];
  estimatedDuration: number;
  certificate: string;
  pricing: {
    freeModules: number;
    premiumPrice: number;
    currency: string;
  };
}

export async function generatePersonalizedCourse(
  skill: string,
  userLevel: 'beginner' | 'intermediate' | 'advanced',
  userGoals: string[]
): Promise<GeneratedCourse> {
  try {
    const prompt = `Create a comprehensive learning course for "${skill}" targeting ${userLevel} level learners.

User Goals: ${userGoals.join(', ')}

Generate a structured course with the following requirements:
1. 8-12 modules total
2. First 3 modules should be free (isPremium: false)
3. Remaining modules are premium (isPremium: true)
4. Mix of content types: video, text, quiz, hands-on
5. Progressive difficulty
6. Practical, industry-relevant content

Return response in JSON format:
{
  "title": "Course title",
  "description": "Detailed course description",
  "skill": "${skill}",
  "difficulty": "${userLevel}",
  "modules": [
    {
      "id": "module_1",
      "title": "Module title",
      "description": "Module description",
      "content": "Detailed module content with learning objectives and key concepts",
      "duration": 45,
      "type": "video",
      "isPremium": false,
      "order": 1
    }
  ],
  "estimatedDuration": 480,
  "certificate": "Certificate name",
  "pricing": {
    "freeModules": 3,
    "premiumPrice": 49.99,
    "currency": "USD"
  }
}`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are an expert course creator specializing in technology and professional skills. Create engaging, practical courses with clear learning outcomes."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.7
    });

    const courseData = JSON.parse(response.choices[0].message.content || '{}');
    return courseData as GeneratedCourse;
  } catch (error) {
    console.error('Error generating course:', error);
    throw new Error('Failed to generate personalized course');
  }
}

export async function generateQuizContent(moduleContent: string): Promise<{
  questions: Array<{
    question: string;
    options: string[];
    correctAnswer: number;
    explanation: string;
  }>;
}> {
  try {
    const prompt = `Based on this module content, create 5 multiple-choice quiz questions:

${moduleContent}

Return response in JSON format:
{
  "questions": [
    {
      "question": "Question text",
      "options": ["Option A", "Option B", "Option C", "Option D"],
      "correctAnswer": 0,
      "explanation": "Why this answer is correct"
    }
  ]
}`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are an expert quiz creator. Create challenging but fair questions that test understanding, not memorization."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.5
    });

    return JSON.parse(response.choices[0].message.content || '{"questions": []}');
  } catch (error) {
    console.error('Error generating quiz:', error);
    throw new Error('Failed to generate quiz content');
  }
}

export async function generateCertificateContent(
  courseName: string,
  userName: string,
  skill: string,
  completionDate: Date
): Promise<string> {
  try {
    const prompt = `Generate a professional certificate content for:
- Course: ${courseName}
- Student: ${userName}
- Skill: ${skill}
- Completion Date: ${completionDate.toDateString()}

Create formal certificate text that includes:
1. Certificate title
2. Recognition statement
3. Course details
4. Skills achieved
5. Professional validation

Keep it professional and industry-standard.`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are a professional certification body. Create formal, industry-recognized certificate content."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      temperature: 0.3
    });

    return response.choices[0].message.content || '';
  } catch (error) {
    console.error('Error generating certificate:', error);
    throw new Error('Failed to generate certificate content');
  }
}