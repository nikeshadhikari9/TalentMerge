import { 
  users, jobs, applications, roadmaps, userProgress, notifications,
  type User, type InsertUser, type Job, type InsertJob, 
  type Application, type InsertApplication, type Roadmap, type InsertRoadmap,
  type UserProgress, type InsertUserProgress, type Notification, type InsertNotification
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, updates: Partial<User>): Promise<User | undefined>;
  
  // Job operations
  getJob(id: number): Promise<Job | undefined>;
  getJobs(): Promise<Job[]>;
  getJobsByOrganization(organizationId: number): Promise<Job[]>;
  createJob(job: InsertJob): Promise<Job>;
  updateJob(id: number, updates: Partial<Job>): Promise<Job | undefined>;
  deleteJob(id: number): Promise<boolean>;
  
  // Application operations
  getApplication(id: number): Promise<Application | undefined>;
  getApplicationsByJob(jobId: number): Promise<Application[]>;
  getApplicationsByUser(userId: number): Promise<Application[]>;
  createApplication(application: InsertApplication): Promise<Application>;
  updateApplication(id: number, updates: Partial<Application>): Promise<Application | undefined>;
  
  // Roadmap operations
  getRoadmap(id: number): Promise<Roadmap | undefined>;
  getRoadmaps(): Promise<Roadmap[]>;
  createRoadmap(roadmap: InsertRoadmap): Promise<Roadmap>;
  
  // User progress operations
  getUserProgress(userId: number, roadmapId: number): Promise<UserProgress | undefined>;
  getUserProgressList(userId: number): Promise<UserProgress[]>;
  createUserProgress(progress: InsertUserProgress): Promise<UserProgress>;
  updateUserProgress(id: number, updates: Partial<UserProgress>): Promise<UserProgress | undefined>;
  
  // Notification operations
  getNotifications(userId: number): Promise<Notification[]>;
  createNotification(notification: InsertNotification): Promise<Notification>;
  markNotificationRead(id: number): Promise<boolean>;
}

export class DatabaseStorage implements IStorage {
  constructor() {
    this.initializeRoadmaps();
  }

  private async initializeRoadmaps() {
    const existingRoadmaps = await db.select().from(roadmaps);
    
    if (existingRoadmaps.length === 0) {
      const defaultRoadmaps: InsertRoadmap[] = [
        {
          name: "React Development",
          skill: "React",
          description: "Master React.js from basics to advanced concepts",
          modules: [
            { id: "1", name: "JSX and Components", completed: false },
            { id: "2", name: "State and Props", completed: false },
            { id: "3", name: "React Hooks", completed: false },
            { id: "4", name: "Context API", completed: false },
            { id: "5", name: "Performance Optimization", completed: false }
          ],
          icon: "fab fa-react",
          color: "blue"
        },
        {
          name: "Node.js Backend",
          skill: "Node.js",
          description: "Learn server-side development with Node.js",
          modules: [
            { id: "1", name: "Express.js Basics", completed: false },
            { id: "2", name: "API Development", completed: false },
            { id: "3", name: "Database Integration", completed: false },
            { id: "4", name: "Authentication", completed: false },
            { id: "5", name: "Deployment", completed: false }
          ],
          icon: "fab fa-node-js",
          color: "green"
        },
        {
          name: "Problem Solving",
          skill: "Problem Solving",
          description: "Develop critical thinking and algorithmic skills",
          modules: [
            { id: "1", name: "Algorithm Basics", completed: false },
            { id: "2", name: "Data Structures", completed: false },
            { id: "3", name: "Code Challenges", completed: false },
            { id: "4", name: "System Design", completed: false },
            { id: "5", name: "Interview Prep", completed: false }
          ],
          icon: "fas fa-brain",
          color: "purple"
        },
        {
          name: "Business Skills",
          skill: "Business",
          description: "Essential business and communication skills",
          modules: [
            { id: "1", name: "Communication", completed: false },
            { id: "2", name: "Project Management", completed: false },
            { id: "3", name: "Leadership", completed: false },
            { id: "4", name: "Team Collaboration", completed: false },
            { id: "5", name: "Strategic Thinking", completed: false }
          ],
          icon: "fas fa-briefcase",
          color: "indigo"
        }
      ];

      await db.insert(roadmaps).values(defaultRoadmaps);
    }
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values({
        ...insertUser,
        bio: insertUser.bio || null,
        profilePicture: insertUser.profilePicture || null,
        skills: insertUser.skills || [],
        certificates: insertUser.certificates || [],
        organizationName: insertUser.organizationName || null,
        location: insertUser.location || null,
        organizationType: insertUser.organizationType || null
      })
      .returning();
    return user;
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set(updates)
      .where(eq(users.id, id))
      .returning();
    return user || undefined;
  }

  // Job operations
  async getJob(id: number): Promise<Job | undefined> {
    const [job] = await db.select().from(jobs).where(eq(jobs.id, id));
    return job || undefined;
  }

  async getJobs(): Promise<Job[]> {
    return await db.select().from(jobs).where(eq(jobs.isActive, true));
  }

  async getJobsByOrganization(organizationId: number): Promise<Job[]> {
    return await db.select().from(jobs).where(eq(jobs.organizationId, organizationId));
  }

  async createJob(insertJob: InsertJob): Promise<Job> {
    const [job] = await db
      .insert(jobs)
      .values({
        ...insertJob,
        requiredSkills: insertJob.requiredSkills || [],
        isActive: true
      })
      .returning();
    
    // Create notifications for matching users
    await this.notifyMatchingUsers(job);
    
    return job;
  }

  async updateJob(id: number, updates: Partial<Job>): Promise<Job | undefined> {
    const [job] = await db
      .update(jobs)
      .set(updates)
      .where(eq(jobs.id, id))
      .returning();
    return job || undefined;
  }

  async deleteJob(id: number): Promise<boolean> {
    const result = await db.delete(jobs).where(eq(jobs.id, id));
    return (result.rowCount || 0) > 0;
  }

  private async notifyMatchingUsers(job: Job): Promise<void> {
    if (!job.requiredSkills) return;
    
    const jobSkills = job.requiredSkills.map(skill => skill.toLowerCase());
    const allUsers = await db.select().from(users).where(eq(users.role, 'jobseeker'));
    
    const matchingUsers = allUsers.filter(user => {
      if (!user.skills) return false;
      return user.skills.some(skill => jobSkills.includes(skill.toLowerCase()));
    });

    for (const user of matchingUsers) {
      await this.createNotification({
        userId: user.id,
        title: "New Job Match!",
        message: `A new job "${job.title}" matches your skills: ${job.requiredSkills?.join(', ')}`,
        type: "job_match"
      });
    }
  }

  // Application operations
  async getApplication(id: number): Promise<Application | undefined> {
    const [application] = await db.select().from(applications).where(eq(applications.id, id));
    return application || undefined;
  }

  async getApplicationsByJob(jobId: number): Promise<Application[]> {
    return await db.select().from(applications).where(eq(applications.jobId, jobId));
  }

  async getApplicationsByUser(userId: number): Promise<Application[]> {
    return await db.select().from(applications).where(eq(applications.userId, userId));
  }

  async createApplication(insertApplication: InsertApplication): Promise<Application> {
    const [application] = await db
      .insert(applications)
      .values({
        ...insertApplication,
        status: "pending"
      })
      .returning();
    return application;
  }

  async updateApplication(id: number, updates: Partial<Application>): Promise<Application | undefined> {
    const [application] = await db
      .update(applications)
      .set(updates)
      .where(eq(applications.id, id))
      .returning();
    return application || undefined;
  }

  // Roadmap operations
  async getRoadmap(id: number): Promise<Roadmap | undefined> {
    const [roadmap] = await db.select().from(roadmaps).where(eq(roadmaps.id, id));
    return roadmap || undefined;
  }

  async getRoadmaps(): Promise<Roadmap[]> {
    return await db.select().from(roadmaps);
  }

  async createRoadmap(insertRoadmap: InsertRoadmap): Promise<Roadmap> {
    const [roadmap] = await db
      .insert(roadmaps)
      .values(insertRoadmap)
      .returning();
    return roadmap;
  }

  // User progress operations
  async getUserProgress(userId: number, roadmapId: number): Promise<UserProgress | undefined> {
    const [progress] = await db
      .select()
      .from(userProgress)
      .where(and(eq(userProgress.userId, userId), eq(userProgress.roadmapId, roadmapId)));
    return progress || undefined;
  }

  async getUserProgressList(userId: number): Promise<UserProgress[]> {
    return await db.select().from(userProgress).where(eq(userProgress.userId, userId));
  }

  async createUserProgress(insertProgress: InsertUserProgress): Promise<UserProgress> {
    const [progress] = await db
      .insert(userProgress)
      .values({
        ...insertProgress,
        progress: 0,
        completedModules: [],
        isCompleted: false,
        completedAt: null
      })
      .returning();
    return progress;
  }

  async updateUserProgress(id: number, updates: Partial<UserProgress>): Promise<UserProgress | undefined> {
    const [progress] = await db
      .update(userProgress)
      .set(updates)
      .where(eq(userProgress.id, id))
      .returning();
    
    if (!progress) return undefined;
    
    // Check if roadmap is completed
    if (progress.progress === 100 && !progress.isCompleted) {
      const completedProgress = {
        ...progress,
        isCompleted: true,
        completedAt: new Date()
      };
      
      const [updatedProgress] = await db
        .update(userProgress)
        .set(completedProgress)
        .where(eq(userProgress.id, id))
        .returning();
      
      // Award certificate
      const roadmap = await this.getRoadmap(updatedProgress.roadmapId);
      if (roadmap) {
        const user = await this.getUser(updatedProgress.userId);
        if (user) {
          const certificates = [...(user.certificates || []), `${roadmap.name} Mastery`];
          await this.updateUser(user.id, { certificates });
          
          // Create notification
          await this.createNotification({
            userId: user.id,
            title: "Certificate Earned!",
            message: `Congratulations! You've earned a certificate in ${roadmap.name}`,
            type: "certificate"
          });
        }
      }
      
      return updatedProgress;
    }
    
    return progress;
  }

  // Notification operations
  async getNotifications(userId: number): Promise<Notification[]> {
    return await db
      .select()
      .from(notifications)
      .where(eq(notifications.userId, userId))
      .orderBy(desc(notifications.createdAt));
  }

  async createNotification(insertNotification: InsertNotification): Promise<Notification> {
    const [notification] = await db
      .insert(notifications)
      .values({
        ...insertNotification,
        isRead: false
      })
      .returning();
    return notification;
  }

  async markNotificationRead(id: number): Promise<boolean> {
    const result = await db
      .update(notifications)
      .set({ isRead: true })
      .where(eq(notifications.id, id));
    return (result.rowCount || 0) > 0;
  }
}

// Temporarily use in-memory storage while fixing database implementation
export class MemStorage implements IStorage {
  private users: Map<number, User> = new Map();
  private jobs: Map<number, Job> = new Map();
  private applications: Map<number, Application> = new Map();
  private roadmaps: Map<number, Roadmap> = new Map();
  private userProgress: Map<number, UserProgress> = new Map();
  private notifications: Map<number, Notification> = new Map();
  
  private currentUserId = 1;
  private currentJobId = 1;
  private currentApplicationId = 1;
  private currentRoadmapId = 1;
  private currentProgressId = 1;
  private currentNotificationId = 1;

  constructor() {
    this.initializeRoadmaps();
  }

  private initializeRoadmaps() {
    const defaultRoadmaps: InsertRoadmap[] = [
      {
        name: "React Development",
        skill: "React",
        description: "Master React.js from basics to advanced concepts",
        modules: [
          { id: "1", name: "JSX and Components", completed: false },
          { id: "2", name: "State and Props", completed: false },
          { id: "3", name: "React Hooks", completed: false },
          { id: "4", name: "Context API", completed: false },
          { id: "5", name: "Performance Optimization", completed: false }
        ],
        icon: "fab fa-react",
        color: "blue"
      },
      {
        name: "Node.js Backend",
        skill: "Node.js",
        description: "Learn server-side development with Node.js",
        modules: [
          { id: "1", name: "Express.js Basics", completed: false },
          { id: "2", name: "API Development", completed: false },
          { id: "3", name: "Database Integration", completed: false },
          { id: "4", name: "Authentication", completed: false },
          { id: "5", name: "Deployment", completed: false }
        ],
        icon: "fab fa-node-js",
        color: "green"
      },
      {
        name: "Problem Solving",
        skill: "Problem Solving",
        description: "Develop critical thinking and algorithmic skills",
        modules: [
          { id: "1", name: "Algorithm Basics", completed: false },
          { id: "2", name: "Data Structures", completed: false },
          { id: "3", name: "Code Challenges", completed: false },
          { id: "4", name: "System Design", completed: false },
          { id: "5", name: "Interview Prep", completed: false }
        ],
        icon: "fas fa-brain",
        color: "purple"
      },
      {
        name: "Business Skills",
        skill: "Business",
        description: "Essential business and communication skills",
        modules: [
          { id: "1", name: "Communication", completed: false },
          { id: "2", name: "Project Management", completed: false },
          { id: "3", name: "Leadership", completed: false },
          { id: "4", name: "Team Collaboration", completed: false },
          { id: "5", name: "Strategic Thinking", completed: false }
        ],
        icon: "fas fa-briefcase",
        color: "indigo"
      }
    ];

    defaultRoadmaps.forEach(roadmap => {
      const id = this.currentRoadmapId++;
      this.roadmaps.set(id, { ...roadmap, id });
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = {
      ...insertUser,
      id,
      bio: insertUser.bio || null,
      profilePicture: insertUser.profilePicture || null,
      skills: insertUser.skills || null,
      certificates: insertUser.certificates || null,
      organizationName: insertUser.organizationName || null,
      location: insertUser.location || null,
      organizationType: insertUser.organizationType || null,
      createdAt: new Date()
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...updates };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Job operations
  async getJob(id: number): Promise<Job | undefined> {
    return this.jobs.get(id);
  }

  async getJobs(): Promise<Job[]> {
    return Array.from(this.jobs.values()).filter(job => job.isActive);
  }

  async getJobsByOrganization(organizationId: number): Promise<Job[]> {
    return Array.from(this.jobs.values()).filter(job => job.organizationId === organizationId);
  }

  async createJob(insertJob: InsertJob): Promise<Job> {
    const id = this.currentJobId++;
    const job: Job = {
      ...insertJob,
      id,
      requiredSkills: insertJob.requiredSkills || null,
      isActive: true,
      createdAt: new Date()
    };
    this.jobs.set(id, job);
    
    // Create notifications for matching users
    await this.notifyMatchingUsers(job);
    
    return job;
  }

  async updateJob(id: number, updates: Partial<Job>): Promise<Job | undefined> {
    const job = this.jobs.get(id);
    if (!job) return undefined;
    
    const updatedJob = { ...job, ...updates };
    this.jobs.set(id, updatedJob);
    return updatedJob;
  }

  async deleteJob(id: number): Promise<boolean> {
    return this.jobs.delete(id);
  }

  private async notifyMatchingUsers(job: Job): Promise<void> {
    if (!job.requiredSkills) return;
    
    const jobSkills = job.requiredSkills.map(skill => skill.toLowerCase());
    const matchingUsers = Array.from(this.users.values()).filter(user => {
      if (user.role !== 'jobseeker') return false;
      if (!user.skills) return false;
      return user.skills.some(skill => jobSkills.includes(skill.toLowerCase()));
    });

    for (const user of matchingUsers) {
      await this.createNotification({
        userId: user.id,
        title: "New Job Match!",
        message: `A new job "${job.title}" matches your skills: ${job.requiredSkills?.join(', ')}`,
        type: "job_match"
      });
    }
  }

  // Application operations
  async getApplication(id: number): Promise<Application | undefined> {
    return this.applications.get(id);
  }

  async getApplicationsByJob(jobId: number): Promise<Application[]> {
    return Array.from(this.applications.values()).filter(app => app.jobId === jobId);
  }

  async getApplicationsByUser(userId: number): Promise<Application[]> {
    return Array.from(this.applications.values()).filter(app => app.userId === userId);
  }

  async createApplication(insertApplication: InsertApplication): Promise<Application> {
    const id = this.currentApplicationId++;
    const application: Application = {
      ...insertApplication,
      id,
      status: "pending",
      appliedAt: new Date()
    };
    this.applications.set(id, application);
    return application;
  }

  async updateApplication(id: number, updates: Partial<Application>): Promise<Application | undefined> {
    const application = this.applications.get(id);
    if (!application) return undefined;
    
    const updatedApplication = { ...application, ...updates };
    this.applications.set(id, updatedApplication);
    return updatedApplication;
  }

  // Roadmap operations
  async getRoadmap(id: number): Promise<Roadmap | undefined> {
    return this.roadmaps.get(id);
  }

  async getRoadmaps(): Promise<Roadmap[]> {
    return Array.from(this.roadmaps.values());
  }

  async createRoadmap(insertRoadmap: InsertRoadmap): Promise<Roadmap> {
    const id = this.currentRoadmapId++;
    const roadmap: Roadmap = { ...insertRoadmap, id };
    this.roadmaps.set(id, roadmap);
    return roadmap;
  }

  // User progress operations
  async getUserProgress(userId: number, roadmapId: number): Promise<UserProgress | undefined> {
    return Array.from(this.userProgress.values()).find(
      progress => progress.userId === userId && progress.roadmapId === roadmapId
    );
  }

  async getUserProgressList(userId: number): Promise<UserProgress[]> {
    return Array.from(this.userProgress.values()).filter(progress => progress.userId === userId);
  }

  async createUserProgress(insertProgress: InsertUserProgress): Promise<UserProgress> {
    const id = this.currentProgressId++;
    const progress: UserProgress = {
      ...insertProgress,
      id,
      progress: 0,
      completedModules: null,
      isCompleted: false,
      completedAt: null
    };
    this.userProgress.set(id, progress);
    return progress;
  }

  async updateUserProgress(id: number, updates: Partial<UserProgress>): Promise<UserProgress | undefined> {
    const progress = this.userProgress.get(id);
    if (!progress) return undefined;
    
    const updatedProgress = { ...progress, ...updates };
    
    // Check if roadmap is completed
    if (updatedProgress.progress === 100 && !updatedProgress.isCompleted) {
      updatedProgress.isCompleted = true;
      updatedProgress.completedAt = new Date();
      
      // Award certificate
      const roadmap = await this.getRoadmap(updatedProgress.roadmapId);
      if (roadmap) {
        const user = await this.getUser(updatedProgress.userId);
        if (user) {
          const certificates = [...(user.certificates || []), `${roadmap.name} Mastery`];
          await this.updateUser(user.id, { certificates });
          
          // Create notification
          await this.createNotification({
            userId: user.id,
            title: "Certificate Earned!",
            message: `Congratulations! You've earned a certificate in ${roadmap.name}`,
            type: "certificate"
          });
        }
      }
    }
    
    this.userProgress.set(id, updatedProgress);
    return updatedProgress;
  }

  // Notification operations
  async getNotifications(userId: number): Promise<Notification[]> {
    return Array.from(this.notifications.values())
      .filter(notif => notif.userId === userId)
      .sort((a, b) => (b.createdAt?.getTime() || 0) - (a.createdAt?.getTime() || 0));
  }

  async createNotification(insertNotification: InsertNotification): Promise<Notification> {
    const id = this.currentNotificationId++;
    const notification: Notification = {
      ...insertNotification,
      id,
      isRead: false,
      createdAt: new Date()
    };
    this.notifications.set(id, notification);
    return notification;
  }

  async markNotificationRead(id: number): Promise<boolean> {
    const notification = this.notifications.get(id);
    if (!notification) return false;
    
    notification.isRead = true;
    this.notifications.set(id, notification);
    return true;
  }
}

export const storage = new MemStorage();
